package com.study.remote;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

	private LinearLayout lightViews;
	private TextView viewIpAddress;
	private SetupDao setupDao;
	private int[] status = new int[] { 0, 0, 0, 0, 0, 0 };
	private List<Button> switchList;
	private List<ImageView> lightList;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		getActionBar().setDisplayHomeAsUpEnabled(true);

		lightViews = (LinearLayout) findViewById(R.id.lightViews);
		viewIpAddress = (TextView) findViewById(R.id.viewIpAddress);
		setupDao = SetupDao.getInstance(this);

		switchList = new ArrayList<Button>();
		lightList = new ArrayList<ImageView>();
		
		// ����СCo��Led1�İ�ť
		LinearLayout layout0 = (LinearLayout) getLayoutInflater().inflate(
				R.layout.view_light, null);
		lightList.add((ImageView) layout0.findViewById(R.id.imageView));
		TextView textView0 = (TextView) layout0.findViewById(R.id.textView);
		textView0.setText("СCo Led1");
		switchList.add((Button) layout0.findViewById(R.id.button));
		lightViews.addView(layout0);
		
		// ����СCo��Led2�İ�ť
		LinearLayout layout1 = (LinearLayout) getLayoutInflater().inflate(
				R.layout.view_light, null);
		lightList.add((ImageView) layout1.findViewById(R.id.imageView));
		TextView textView1 = (TextView) layout1.findViewById(R.id.textView);
		textView1.setText("СCo Led2");
		switchList.add((Button) layout1.findViewById(R.id.button));
		lightViews.addView(layout1);
		
		// ����СEn��Led1�İ�ť
		LinearLayout layout2 = (LinearLayout) getLayoutInflater().inflate(
				R.layout.view_light, null);
		lightList.add((ImageView) layout2.findViewById(R.id.imageView));
		TextView textView2 = (TextView) layout2.findViewById(R.id.textView);
		textView2.setText("СEn Led1");
		switchList.add((Button) layout2.findViewById(R.id.button));
		lightViews.addView(layout2);
		
		// ����СEn��Led2�İ�ť
		LinearLayout layout3 = (LinearLayout) getLayoutInflater().inflate(
				R.layout.view_light, null);
		lightList.add((ImageView) layout3.findViewById(R.id.imageView));
		TextView textView3 = (TextView) layout3.findViewById(R.id.textView);
		textView3.setText("СEn Led2");
		switchList.add((Button) layout3.findViewById(R.id.button));
		lightViews.addView(layout3);
		
		// ����СCo�ļ̵����İ�ť
		LinearLayout layout4 = (LinearLayout) getLayoutInflater().inflate(
				R.layout.view_relay, null);
		lightList.add((ImageView) layout4.findViewById(R.id.relayView));
		TextView textView4 = (TextView) layout4.findViewById(R.id.textView);
		textView4.setText("�̵���");
		switchList.add((Button) layout4.findViewById(R.id.button));
		lightViews.addView(layout4);
		
		// ����СCo�ķ������İ�ť
		LinearLayout layout5 = (LinearLayout) getLayoutInflater().inflate(
				R.layout.view_beep, null);
		lightList.add((ImageView) layout5.findViewById(R.id.beepView));
		TextView textView5 = (TextView) layout5.findViewById(R.id.textView);
		textView5.setText("������");
		switchList.add((Button) layout5.findViewById(R.id.button));
		lightViews.addView(layout5);
		
		viewIpAddress.setText("Server Ip:" + setupDao.getString("IpAddress"));
	}

	@Override
	protected void onResume() {
		if (TextUtils.isEmpty(setupDao.getString("IpAddress"))) {
			inputIpAddress();
		}else{
			new StatusTask(MainActivity.this,"Query Status").execute();
		}
		super.onResume();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.main, menu);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			finish();
			return true;
		case R.id.setting:
			inputIpAddress();
			return true;
		case R.id.refresh:
			new StatusTask(MainActivity.this,"Query Status").execute();
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	private void inputIpAddress() {
		final EditText editIpAddress = new EditText(this);
		editIpAddress.setText(setupDao.getString("IpAddress"));
		new AlertDialog.Builder(this).setTitle("������IP��ַ")
				.setIcon(android.R.drawable.ic_dialog_info)
				.setView(editIpAddress)
				.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface arg0, int arg1) {
						setupDao.putString("IpAddress", editIpAddress.getText()
								.toString());
						viewIpAddress.setText("Server Ip:"
								+ setupDao.getString("IpAddress"));
						new StatusTask(MainActivity.this,"Query Status").execute();
					}
				}).setNegativeButton("ȡ��", null).show();
	}

	public void switch_click(View v) {
		if (TextUtils.isEmpty(setupDao.getString("IpAddress"))) {
			Toast.makeText(this, "Please setting ip address!",
					Toast.LENGTH_LONG).show();
			return;
		}
		int index = switchList.indexOf(v);
		if (status[index] == 0) {
			new SendTask(this, "Sending", index).execute(1 + "");
		} else {
			new SendTask(this, "Sending", index).execute(0 + "");
		}
	}

	private class StatusTask extends BaseTask {

		public StatusTask(Context context, String message) {
			super(context, message);
		}

		@Override
		protected String doInBackground(String... params) {
			Socket socket = null;
			Scanner scanner = null;
			PrintWriter out = null;
			try {
				socket = new Socket(setupDao.getString("IpAddress"), 8002);
				scanner = new Scanner(socket.getInputStream());
				out = new PrintWriter(socket.getOutputStream());
				out.println("status");
				out.flush();
				String line = scanner.nextLine();
				if (!TextUtils.isEmpty(line)) {
					String[] tokens = line.split(",");
					if (tokens.length == 6) {
						for (int i = 0; i < tokens.length; i++) {
							status[i] = Integer.parseInt(tokens[i]);
						}
					}
				}

			} catch (IOException e) {
				return e.getMessage();
			} finally {
				if (out != null)
					out.close();
				if (scanner != null)
					scanner.close();
				if (socket != null)
					try {
						socket.close();
					} catch (IOException e) {
						return e.getMessage();
					}
			}
			return "ok";
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			if(result.equals("ok")){
				for(int i=0;i<status.length;i++){
					if(status[i]==0){
						switchList.get(i).setBackgroundResource(R.drawable.switch_off);
						if(i<4)
						{
							lightList.get(i).setBackgroundResource(R.drawable.light_off);	
						}
					}else{
						switchList.get(i).setBackgroundResource(R.drawable.switch_on);
						if(i<4)
						{
							lightList.get(i).setBackgroundResource(R.drawable.light_on);	
						}						
					}
				}
			}
		}
	}

	private class SendTask extends BaseTask {

		private int index;

		public SendTask(Context context, String message, int index) {
			super(context, message);
			this.index = index;
		}

		@Override
		protected String doInBackground(String... params) {
			Socket socket = null;
			Scanner scanner = null;
			PrintWriter out = null;
			try {
				socket = new Socket(setupDao.getString("IpAddress"), 8002);
				scanner = new Scanner(socket.getInputStream());
				out = new PrintWriter(socket.getOutputStream());
				out.println("set:"+index+"="+params[0]);
				out.flush();
			} catch (IOException e) {
				return e.getMessage();
			} finally {
				if (scanner != null)
					scanner.close();
				if (out != null)
					out.close();
				if (socket != null)
					try {
						socket.close();
					} catch (IOException e) {
						return e.getMessage();
					}
			}
			return "ok";
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute(result);
			if (!result.equalsIgnoreCase("ok")) {
				Toast.makeText(MainActivity.this, result, Toast.LENGTH_SHORT)
						.show();
			} else {
				new StatusTask(MainActivity.this,"Query Status").execute();
			}
		}
	}
}
